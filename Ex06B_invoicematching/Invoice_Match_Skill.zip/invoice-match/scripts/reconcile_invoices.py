"""Match invoice lines to purchase orders and cumulative receipts."""
import argparse
from collections import defaultdict
from decimal import Decimal
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter


def reconcile(purchasing, invoices, destination):
    if destination.resolve() in (purchasing.resolve(), invoices.resolve()) or destination.exists():
        raise ValueError("Choose a new output file to preserve existing workbooks.")
    workbook = load_workbook(purchasing)
    invoice_book = load_workbook(invoices, read_only=True)
    invoice_sheet = workbook.create_sheet("Supplier Invoices")
    for row in invoice_book["Supplier Invoices"].values:
        invoice_sheet.append(row)
    invoice_book.close()
    orders = {}
    for po, line, item, ordered, price in workbook["Purchase Orders"].iter_rows(
        min_row=2, values_only=True
    ):
        key = (po, line)
        if key in orders:
            raise ValueError(f"Duplicate purchase order line: {key}")
        orders[key] = (ordered, Decimal(str(price)))

    receipts = defaultdict(int)
    for receipt, po, line, received in workbook["Receiving Log"].iter_rows(
        min_row=2, values_only=True
    ):
        receipts[po, line] += received

    headers = [
        "Invoice", "PO", "Line", "Billed", "Prior Billed", "Ordered", "Received",
        "PO Unit Price", "Invoice Unit Price", "Excess Units vs Receipts",
        "Excess at Invoice Price", "Finding"
    ]
    results = workbook.create_sheet("Match Results")
    exceptions = workbook.create_sheet("Exceptions")
    for sheet in (results, exceptions):
        sheet.append(headers)

    billed_so_far = defaultdict(int)
    for invoice, po, line, billed, raw_price in workbook["Supplier Invoices"].iter_rows(
        min_row=2, values_only=True
    ):
        key = (po, line)
        prior = billed_so_far[key]
        billed_so_far[key] += billed
        invoice_price = Decimal(str(raw_price))
        ordered = po_price = received = excess = amount = None
        findings = []
        if key not in orders:
            findings.append("Missing PO line")
        else:
            ordered, po_price = orders[key]
            received = receipts[key]
            excess = max(0, billed - max(0, received - prior))
            amount = excess * invoice_price
            if excess:
                findings.append("Billed above receipts")
            if billed > max(0, ordered - prior):
                findings.append("Billed above order")
            if invoice_price != po_price:
                findings.append("Unit price mismatch")
        row = [
            invoice, po, line, billed, prior, ordered, received,
            po_price, invoice_price, excess, amount, ", ".join(findings) or "Matched"
        ]
        results.append(row)
        if findings:
            exceptions.append(row)

    for sheet in (results, exceptions):
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        for column in sheet.columns:
            heading = column[0]
            heading.fill = PatternFill("solid", fgColor="17365D")
            heading.font = Font(color="FFFFFF", bold=True)
            width = max(len(str(cell.value or "")) for cell in column) + 3
            sheet.column_dimensions[get_column_letter(heading.column)].width = width
        for row in sheet.iter_rows(min_row=2):
            for index in (7, 8, 10):
                row[index].number_format = '"$"#,##0.00'
    workbook.save(destination)
    print(f"{results.max_row - 1} invoice lines, {exceptions.max_row - 1} exceptions")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("purchasing", type=Path)
    parser.add_argument("invoices", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    reconcile(args.purchasing, args.invoices, args.output)
