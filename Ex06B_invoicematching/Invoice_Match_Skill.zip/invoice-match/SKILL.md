---
name: invoice-match
description: Run three-way invoice matching using two Excel workbooks, one for purchase orders and receipts and one for supplier invoices.
---

# Three Way Invoice Matching

Use Python 3 and openpyxl. Resolve the script path relative to this skill folder and run:

`python scripts/reconcile_invoices.py "<purchasing.xlsx>" "<invoices.xlsx>" "<output.xlsx>"`

The purchasing workbook needs Purchase Orders and Receiving Log. The invoice workbook needs Supplier Invoices. Use the lab's headers and column order. Rows must be complete, quantities and prices numeric, and invoices ordered oldest to newest. Multiple receipts on one PO line are summed, and prior invoice rows reduce the quantity available.

Use a fresh output path. Return the generated workbook and summarize Match Results and Exceptions. Report errors directly if the script cannot complete.
